#pragma once

#define MCP3204_CHANNEL_0_OFST (0 * 4) /* RO */
#define MCP3204_CHANNEL_1_OFST (1 * 4) /* RO */
#define MCP3204_CHANNEL_2_OFST (2 * 4) /* RO */
#define MCP3204_CHANNEL_3_OFST (3 * 4) /* RO */
